import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    //Definierung der Variablen mit Datentypen
    private SimpleTimer timer = new SimpleTimer();
    private int StepCounter;
    private int RoundCheck;
    
    String status;
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        super(1200, 800, 1); // Erstellen einer neuen Welt in der Grösse 1200x800 mit 1x1 Pixel.
        
        //Abruf der Methoden
        spawnHouses();
        spawnAdmin();

    }
    
    public void act(){
        Steps();
        displayText();
    }
    
    private void spawnHouses(){
        //Die Häuser werden erzeugt und an die Koordinaten gesetzt.
        addObject(new Sender(), 246, 172);
        addObject(new Empfaenger(), 941, 172);
    
    }
    
    private void displayText(){
       showText("Status: " + status, 270, 40);
 
    
    }
    
    private void spawnAdmin(){
        //Server und Zustelldienst werden erzeugt und an die Koordinaten gesetzt.
        addObject(new AuftragsSystem(), 610, 415);
        addObject(new DeliveryService(), 610, 674);
    
    }
    
    public void Steps(){
        
        if(timer.millisElapsed() > 2000 && RoundCheck == 0){
            addObject(new Arrow(), 452, 318);
            status = "Neuer Auftrag ins System aufgegeben";
            RoundCheck++;
        
        }
        
        if(timer.millisElapsed() > 4000 && RoundCheck == 1){
            addObject(new Arrow2(), 594, 582);
            removeObjects(getObjects(Arrow.class));
            status = "Auftrag wird dem Zustelldienst weitergeleitet";
            RoundCheck++;
        
        }
        
        if(timer.millisElapsed() > 4500 && RoundCheck == 2){
            addObject(new Package(), 255, 304);
            removeObjects(getObjects(Arrow2.class));
            status = "Sender bereitet Paket vor";
            RoundCheck++;
        
        }
        
        if(timer.millisElapsed() > 5500 && RoundCheck == 3){
            addObject(new Drone(), 453, 651);
            status = "Drone startet vom Zustelldienst";
            RoundCheck++;
        
        }
        
        if(timer.millisElapsed() > 6500 && RoundCheck == 4){
            removeObjects(getObjects(Drone.class));
            addObject(new Drone(), 117, 331);
            status = "Drone ist unterwegs";
            RoundCheck++;
        
        }
        
        if(timer.millisElapsed() > 7000 && RoundCheck == 5){
            removeObjects(getObjects(Drone.class));
            removeObjects(getObjects(Package.class));
            addObject(new Drone(), 301, 456);
            addObject(new Package(), 306, 528);
            status = "Drone nimmt Paket entgegen";
            RoundCheck++;
        
        }
        
        if(timer.millisElapsed() > 7500 && RoundCheck == 6){
            removeObjects(getObjects(Drone.class));
            removeObjects(getObjects(Package.class));
            addObject(new Drone(), 435, 621);
            addObject(new Package(), 442, 691);
            status = "Drone kehrt mit dem Paket zurück";
            RoundCheck++;
        
        }
        
        if(timer.millisElapsed() > 8000 && RoundCheck == 7){
            removeObjects(getObjects(Drone.class));
            removeObjects(getObjects(Package.class));
            status = "Zustelldienst hat das Paket erfolgreich erhalten";
            RoundCheck++;
        
        }
        
        if(timer.millisElapsed() > 8500 && RoundCheck == 8){
            addObject(new Drone(), 800, 612);
            addObject(new Package(), 802, 684);
            status = "Zustelldienst entsendet Drone für Zustellung";
            RoundCheck++;
        
        }
        
        if(timer.millisElapsed() > 9000 && RoundCheck == 9){
            removeObjects(getObjects(Drone.class));
            removeObjects(getObjects(Package.class));
            addObject(new Drone(), 936, 463);
            addObject(new Package(), 942, 538);
            status = "Drone ist unterwegs für die Zustellung";
            RoundCheck++;
        
        }
        
        if(timer.millisElapsed() > 9500 && RoundCheck == 10){
            removeObjects(getObjects(Drone.class));
            removeObjects(getObjects(Package.class));
            addObject(new Drone(), 997, 302);
            addObject(new Package(), 1002, 370);
            status = "Drone ist angekommen";
            RoundCheck++;
        
        }
        
        if(timer.millisElapsed() > 10000 && RoundCheck == 11){
            removeObjects(getObjects(Package.class));
            status = "Paket wurde erfolgreich abgeliefert";
            RoundCheck++;
        
        }
        
        if(timer.millisElapsed() > 10500 && RoundCheck == 12){
            removeObjects(getObjects(Drone.class));
            addObject(new Drone(), 954, 472);
            status = "Drone kehrt zum Zustelldienst zurück";
            RoundCheck++;
        
        }
        
        if(timer.millisElapsed() > 11000 && RoundCheck == 13){
            removeObjects(getObjects(Drone.class));
            addObject(new Drone(), 806, 652);
            status = "Drone ist erfolgreich beim Zustelldienst angekommen";
            RoundCheck++;
        
        }
        
        if(timer.millisElapsed() > 12000 && RoundCheck == 14){
            removeObjects(getObjects(Drone.class));
            addObject(new Arrow3(), 753, 310);
            status = "Empfänger ändert den Status der Lieferung";
            RoundCheck++;
        
        }
        
        if(timer.millisElapsed() > 12500 && RoundCheck == 15){
            removeObjects(getObjects(Arrow3.class));
            addObject(new Arrow4(), 446, 263);
            addObject(new Arrow2(), 594, 582);
            status = "Auftragssystem informiert Sender und Zustelldienst von der erfolgreichen Zustellung";
            RoundCheck++;
        
        }
        
        
    
    }
    
}
